#include<stdio.h>
int main()
{
// this is a comment 
printf("Hello RNSIT");
/* This is another comment */
}
