#include<stdio.h>
int main()
{
if(true) printf("1\n");
printf("Hello Imam");

}
